ALTER TABLE `clients` ADD COLUMN `notes` text;
