ALTER TABLE `studio_users`
  ADD COLUMN `pinHash` TEXT NULL AFTER `passwordHash`;
